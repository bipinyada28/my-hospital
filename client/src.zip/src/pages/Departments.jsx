
export default function Departments() {
  return (
    <div className="text-center p-6">
      <h2 className="text-2xl font-semibold text-hospitalBlue mb-2">Departments</h2>
      <p>List of all hospital departments will go here.</p>
    </div>
  );
}
