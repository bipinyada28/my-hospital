export default function Home() {
  return (
<div className="bg-lightgrey min-h-screen p-6">
  <h1 className="text-4xl font-bold text-primary">Welcome to True Heal</h1>
  <p className="text-aqua mt-2">Your health is our priority</p>
</div>
  );
}
